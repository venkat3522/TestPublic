define( function ( require ) {

	"use strict";

	return {
		app_slug : 'com_dataviolet_shop3',
		wp_ws_url : 'https://dataviolet.com/shop/wp-appkit-api/com_dataviolet_shop3',
		wp_url : 'https://dataviolet.com/shop',
		theme : 'q-android',
		version : '1.4',
		app_type : 'phonegap-build',
		app_title : 'DataViolet_Shop3',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : '8ZjG})2E#mZdEJOvb0c;#5eMa|V}3AZPY2b6[3*aD:;RA!Q.>#QShu[C;R^d-du$',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
